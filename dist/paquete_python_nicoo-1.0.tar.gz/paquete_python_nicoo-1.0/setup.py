from setuptools import setup

setup(
    
name = "paquete_python_nicoo",
version = "1.0",
description = "Estoy haciendo mi primer paquete",
author = "Nicolas Botta",
author_email = "Nicolasbotta5@gmail.com",
    
packages = ["paquete_python_nicoo"]
)